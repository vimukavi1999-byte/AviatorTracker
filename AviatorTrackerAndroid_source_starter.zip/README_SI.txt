AVIATOR TRACKER — ANDROID SOURCE STARTER (v0.1)

මෙය APK එකක් නොව Android Studio/Gradle source project එකකි.
මෙහි ඇතුළත්:
- Android app project skeleton
- ෆෝන් එකේම local history save කිරීමේ sample
- Android screen-capture permission prompt එක පරීක්ෂා කිරීම
- GitHub Actions හරහා debug APK build කිරීමේ workflow

වැදගත්:
- 1xBet screen එකෙන් auto capture / OCR extraction තවම සම්බන්ධ කර නැත.
- Bet time, crash time, multiplier, bets count, total bets, total winnings ස්වයංක්‍රීයව කියවීම තවම සම්පූර්ණ නැත.
- "Save sample round" button එක sample data පමණක් save කරයි.
- APK build කළත් එය production-ready app එකක් නොවේ; OCR සහ background screen capture එක සම්බන්ධ කර test කළ යුතුය.

PC නැතිව build කිරීමට:
1. ZIP එක unzip කර GitHub repository එකකට upload කරන්න (Android phone browser එකෙන් කළ හැක).
2. Repository එකේ Actions tab එකට යන්න.
3. "Build Android APK" workflow එක run කරන්න.
4. Build අවසන් වූ පසු Artifacts යටතේ AviatorTracker-debug-apk download කරන්න.
5. APK install කිරීමට Android හි unknown-app install permission අවශ්‍ය විය හැක.

මෙය 1xBet login/password හෝ account data කිසිවක් එකතු නොකරයි.
