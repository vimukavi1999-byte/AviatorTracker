package com.example.aviatortracker

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Starter scaffold. Screen capture permission is requested by Android.
 * The actual ongoing MediaProjection frame-capture service and robust Aviator
 * screen-region OCR still need implementation/testing before this is a working
 * automatic tracker.
 */
class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var history: TextView
    private val prefs by lazy { getSharedPreferences("rounds", Context.MODE_PRIVATE) }
    private val projectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    private val capturePermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            status.text = "Screen-capture permission granted. Capture/OCR service is not wired up yet."
            Toast.makeText(this, "Permission granted — prototype only", Toast.LENGTH_LONG).show()
        } else {
            status.text = "Screen capture permission not granted."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Aviator Tracker"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "Prototype source project — automatic reading is not active yet."
            textSize = 15f
            setPadding(0, 18, 0, 18)
        }
        val permissionButton = Button(this).apply {
            text = "Test screen-capture permission"
            setOnClickListener { capturePermission.launch(projectionManager.createScreenCaptureIntent()) }
        }
        val sampleButton = Button(this).apply {
            text = "Save sample round"
            setOnClickListener {
                val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
                val obj = JSONObject().apply {
                    put("saved_at", stamp)
                    put("bet_time", "")
                    put("crash_time", "")
                    put("multiplier", "33.58x (sample)")
                    put("bets_count", 2412)
                    put("total_bets_lkr", 1328270.04)
                    put("total_winnings_lkr", 4867275.12)
                }
                val arr = JSONArray(prefs.getString("history", "[]"))
                arr.put(obj)
                prefs.edit().putString("history", arr.toString()).apply()
                refreshHistory()
                Toast.makeText(this@MainActivity, "Sample round saved on this phone", Toast.LENGTH_SHORT).show()
            }
        }
        val refreshButton = Button(this).apply {
            text = "Refresh saved history"
            setOnClickListener { refreshHistory() }
        }
        history = TextView(this).apply {
            textSize = 14f
            setPadding(0, 20, 0, 0)
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(permissionButton)
        layout.addView(sampleButton)
        layout.addView(refreshButton)
        layout.addView(history)
        val scroll = ScrollView(this).apply {
            addView(layout, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ))
        }
        setContentView(scroll)
        refreshHistory()
    }

    private fun refreshHistory() {
        val arr = JSONArray(prefs.getString("history", "[]"))
        val out = StringBuilder("Saved rounds: ${arr.length()}\n\n")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            out.append("${o.optString("saved_at")}\n")
            out.append("Crash: ${o.optString("multiplier")} | Bets: ${o.optString("bets_count")}\n")
            out.append("Total bets: LKR ${o.optString("total_bets_lkr")}\n")
            out.append("Total winnings: LKR ${o.optString("total_winnings_lkr")}\n\n")
        }
        history.text = out.toString()
    }
}
